# Faculty Feedback Portal 🎓

A modern, responsive, and lightweight student evaluation and faculty analytics web portal built with pure HTML5, CSS3, and modern JavaScript.

---

## 🌟 Key Features

- **Dynamic Role-Based Login:**
  - **Student Login:** Registration Number only — no password required.
  - **Faculty Login:** Numeric UID input enforcement and password authentication.
- **Student Feedback Flow:**
  - View enrolled courses and respective faculty.
  - Interactive 5-star rating system across 5 key metrics:
    - Teaching Quality
    - Subject Clarity
    - Punctuality
    - Course Content
    - Overall Satisfaction
  - Optional written feedback/comments.
  - Prevention of duplicate submissions for the same course.
  - Complete submission history table (`history.html`).
- **Faculty Dashboard & Analytics:**
  - Real-time statistics: Total Courses, Total Submissions count, and Average Aggregate Rating out of 5.0.
  - Course and faculty roster view.
  - Chronological student feedback table with ratings and comments.
- **Client-Side Persistence:**
  - Utilizes HTML5 `localStorage` for cross-session feedback storage and `sessionStorage` for active login sessions. Zero backend or database setup required.

---

## 🚀 How to Run on Any Device

### Option 1: Direct in Any Browser (Zero Installation)
Simply open `index.html` in any modern web browser (Google Chrome, Firefox, Safari, Edge).

### Option 2: Run with a Local Server
If you prefer running via a local development server:
```bash
# Using Python (built-in on Mac & Linux):
python3 -m http.server 3000

# Or using Node.js / npx:
npx serve .
```
Then visit `http://localhost:3000` in your browser.

---

## 📁 Project Structure

```text
├── index.html        # Dynamic login page (Student & Faculty)
├── feedback.html     # Course listing & feedback submission form
├── history.html      # Student feedback submission history
├── admin.html        # Faculty overview & analytics dashboard
├── script.js         # Core application logic & data handling
├── style.css         # Styling, layout, and responsive design
└── README.md         # Project documentation
```

---

## 👥 Demo Credentials

- **Student:** Any Registration Number (e.g., `12345678`) — No password needed.
- **Faculty:** Any numeric UID (e.g., `1001` or `9001`) + any password.
